/*
    原生js实现瀑布流布局
* */

window.onload = function(){
    waterfall('main','box');
    window.onscroll = function(){
        //要加载的图片
        var imgJson = {'data':[{'src':'1.jpg'},{'src':'2.jpg'},{'src':'3.jpg'},{'src':'4.jpg'},{'src':'5.jpg'}]};


        var oParent = document.getElementById("main");
        var oBox = getChildByClass(oParent,"box");
        //获取滚动条移动的距离
        var scrollMoveH = document.body.scrollTop || document.documentElement.scrollTop;

        //滚动x后开始加载其他图片 = 页面最后一张图片的一半高度加上其距离窗口上方的距离鉴于窗口的高度
        var windowH = document.body.clientHeight || document.documentElement.clientHeight;//窗口高度
        //最后一张图片的中部距离窗口的顶部的距离
        var lastImghalfH = oBox[oBox.length-1].offsetTop + Math.floor(oBox[oBox.length-1].offsetHeight/2);
        var beginLoadLine = lastImghalfH - windowH;//当滚动beginLoadLine距离时开始加载其他图片
        if(scrollMoveH >beginLoadLine){
            //将要加载的图片添加到页面中。
            for(var i=0;i<imgJson.data.length;i++){
                var oBoxDiv = document.createElement("div");
                oBoxDiv.className = "box";
                oParent.appendChild(oBoxDiv);
                var oImg = document.createElement('img');
                oImg.src = "images/"+imgJson.data[i].src;
                oBoxDiv.appendChild(oImg);
            }
            waterfall('main','box');
        }
        /*
            1、判断滚动到什么时候刷新
                当滚动条下拉到最后一张图像的1/2距离时加载其他图片
        * */
    }
};
function waterfall(parentId,child){
    var oParent = document.getElementById(parentId);
    //通过oParent获得所有的子元素
    var oBox = getChildByClass(oParent,child);

    //计算页面box的数量并取整
    var num = Math.floor(document.documentElement.clientWidth/oBox[0].offsetWidth);

    //设置main宽度
    oParent.style.cssText = "width:"+ oBox[0].offsetWidth * num + "px;margin:0 auto";

    var oBoxArr = new Array();
    var minH = 0;
    for(var i=0;i<oBox.length;i++){
        if(i<num){
            oBoxArr.push(oBox[i].offsetHeight);
        }else{
           //找出一行中box最低的box
           minH = Math.min.apply(null,oBoxArr);
           //找出最小值在数值中对应的位置
           var area = indexByMinH(minH,oBoxArr);
           oBox[i].style.position = "absolute";
           oBox[i].style.left = oBox[area].offsetLeft + "px";
           oBox[i].style.top = oBoxArr[area] + "px";
           oBoxArr[area] = oBoxArr[area] + oBox[i].offsetHeight;
       }


    }
}
//通过oParent获得所有的子元素
function getChildByClass(parent,childname){
    var cName = parent.getElementsByClassName(childname);
    return cName;
}

//找出最小值在数值中对应的位置
function indexByMinH(minH,arr){
    for(var i=0;i<arr.length;i++){
        if(minH == arr[i]){
            return i;
        }
    }
}


/*
步骤：
1、取出所有元素
2、计算页面的宽高,计算每个页面有多少个box（页面宽/box宽）
3、根据box数量设置mian的宽度并居中显示.
4、从第二排开始每次将box添加到height最低的列下面.
    1、判断页面一行有几个box，并找出出高度最低的box
    2、将下一个box添加到高度最低的box底下
    3、每次重新计算高度最低的box并将下个box添加到最低的box下面

* */