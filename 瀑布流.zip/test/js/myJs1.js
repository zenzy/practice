/*
    jQuery实现瀑布流布局
* */

$(window).on('load',function(){
    waterfall();
    var imgJson = {'data':[{'src':'1.jpg'},{'src':'2.jpg'},{'src':'3.jpg'},{'src':'4.jpg'},{'src':'5.jpg'}]};
    $(window).on('scroll',function(){
        //当滚动条滚动到最后一张图片的一般二分之一高度时开始加载数据
        var $oBox = $("#main>div");
        var windowH = $(window).height();
        var lastImgHalfH = Math.floor($oBox.last().offset().top + $oBox.last().outerHeight()/2);
        var scrollH = $(window).scrollTop();
        if(scrollH>lastImgHalfH-windowH){
            //加载图片
            $.each(imgJson.data,function(index,element){
                var oBoxDiv = $('<div>').addClass('box').appendTo($('#main'));
                $('<img>').attr('src','images/'+$(element).attr('src')).appendTo(oBoxDiv);
            });
            waterfall();
        }

    })
});

//实现图片布局
function waterfall(){
    var $oParent = $("#main");
    var $oBox = $("#main>div");

    //获取页面中有多少个box:页面宽度/box宽度
    var boxW = $oBox.eq(0).outerWidth();
    var cols = Math.floor($(window).width()/boxW);

    //设置main的宽度并居中显示
    $oParent.width(cols*boxW).css("margin","0 auto");

    //将图片添加到上一行的box最低高度的下面
    var oBoxArr = [];
    $oBox.each(function(index,element){
        var oBoxH = $oBox.eq(index).outerHeight();
        if(index<cols){
            oBoxArr.push(oBoxH);
        }else{
            var minH = Math.min.apply(null,oBoxArr);//获取上一行最低高度
            //将下一个图片添加到最低高度的那张图片下面并改变oBoxArr数组中的最低高度
            //找到数组中最低高度图片的位置
            var minHeightPosi = $.inArray(minH,oBoxArr);
            $(element).css({
                'position':'absolute',
                'left':boxW*minHeightPosi + 'px',
                'top':oBoxArr[minHeightPosi]+'px'
            });
            oBoxArr[minHeightPosi] = oBoxArr[minHeightPosi] + $(element).outerHeight();
        }
    })

}



/*

* */